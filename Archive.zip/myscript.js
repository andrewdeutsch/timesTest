var imported = document.createElement('script');
imported.src = 'http://np-ec2-nytimes-com.s3.amazonaws.com/dev/test/nyregion.js';
document.head.appendChild(imported);

var NYTD = {
      data : {},
      render_section_front : function (params){
        this.data = params;
        this.parseData();
      },
      parseData : function(){
        
        for(var i=0;i<this.data.page.content[1].collections.length; i++){
            var cl1 = this.data.page.content[1].collections[i].assets;
            //console.log(this.data.page.content[1].collections.length);
            //console.log(cl1);

            //$('body').append('<h1>'+cl.name+'</h1>');

        // var cl = json.league[i];
        // $('body').append('<h1>'+cl.name+'</h1>');
        // var ul = $('<ul/>').appendTo('body');
        // for(var j=0;j<cl.event.length;j++){
        //    var ce = cl.event[j];
        //     ul.append($('<li/>').append(ce.name+' '+ce.id+' '+ce.odds));
        // }
    }
        for(var i=0;i<this.data.page.content[2].collections[i].assets.length; i++){
            var cl2 = this.data.page.content[2].collections[i].assets;
            //console.log(this.data.page.content[1].collections.length);
           // console.log(cl2.length);
            console.log(cl2[i].headline);
        }


        
        // var headline = this.data.page.content[1].collections[0].assets[0].headline;
        // var summary = this.data.page.content[1].collections[0].assets[0].summary;
        // var byline = this.data.page.content[1].collections[0].assets[0].byline;
        // console.log(byline);

        // var imageRetrieved = 'http://www.nytimes.com/'+this.data.page.content[1].collections[0].assets[0].images[0].types[4].content

        // //adding to dom elements
        // $(".headline").append('<div>' + headline + '</div>');
        // $(".summary").append('<div>' + summary + '</div>');
        // $(".byline").append('<div>' + byline + '</div>');
        // $( "<img>" ).attr( "src", imageRetrieved ).appendTo( "#images" );

        // var output = '';

        // for (var i = 0; i <= this.data.page.content.length; i++) {
        //     for (key in this.data.page.content[i]) {
        //         if (this.data.page.content[i].hasOwnProperty(key)) {
        //             output +=  key ;
        //         } // hasOwnProperty check
        //     } // for each object
        // } //for each array element

        // var headlines = document.getElementsByClassName('headline');
        // headlines.innerHTML = output;
      }
    };