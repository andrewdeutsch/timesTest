var imported = document.createElement('script');
imported.src = 'http://np-ec2-nytimes-com.s3.amazonaws.com/dev/test/nyregion.js';
document.head.appendChild(imported);

var NYTD = {
      data : {},
      render_section_front : function (params){
        this.data = params;
        this.parseData();
      },
      parseData : function(){
        
        var storyHolder = document.getElementById("storyBits");

        // var header = document.createElement('div');
        // var summary = document.createElement('div');
        // var byline = document.createElement('div');

        
        //accessing the first batch of content
        for(var i=0;i<this.data.page.content[1].collections.length; i++){
            var cl1 = this.data.page.content[1].collections[i].assets;
            //var image1 = this.data.page.content[1].collections[i].assets[i].images[i].types;
            //var image1 = 'http://www.nytimes.com/'+this.data.page.content[1].collections[i].assets[i].images[0].types[4].content;

                for (var k=0; k<cl1.length; k++){
                    var header = document.createElement('div');
                    var summary = document.createElement('div');
                    var byline = document.createElement('div');

                    header.className = 'header';
                    summary.className ='summary';
                    byline.className = 'byline';

                    var divs = [header, byline, summary];

                    var docFrag = document.createDocumentFragment();

                    if (cl1[k].headline == "Only rank in summary collections" ){
                        header.innerHTML = "";
                        byline.innerHTML = "";
                        summary.innerHTML = "";

                    }else if (cl1[k].headline == undefined){
                        header.innerHTML = "";
                        byline.innerHTML = "";
                        summary.innerHTML = "";
                    }
                    else {
                        header.innerHTML = cl1[k].headline;
                        byline.innerHTML = cl1[k].byline;
                        summary.innerHTML = cl1[k].summary;

                        for(var l = 0; l < divs.length; l++) {
                          docFrag.appendChild(divs[l]);
                          storyHolder.appendChild(docFrag );
                        }
                    }
                }
      
       
    }
        //accessing the second batch of content
        for(var j=0;j<this.data.page.content[2].collections.length; j++){
            var cl2 = this.data.page.content[2].collections[j].assets;
                for (var m=0; m<cl2.length; m++){
                    var header = document.createElement('div');
                    var summary = document.createElement('div');
                    var byline = document.createElement('div');

                    header.className = 'header';
                    summary.className ='summary';
                    byline.className = 'byline';


                    var divs = [header, byline, summary];

                    var docFrag = document.createDocumentFragment();
                    
                     if (cl2[m].headline == "Only rank in summary collections" ){ 
                        header.innerHTML = "";
                        byline.innerHTML = "";
                        summary.innerHTML = "";

                    }else if (cl2[m].headline == undefined){
                        //console.log('cl2[m].headline is undefined');
                        header.innerHTML = "";
                        byline.innerHTML = "";
                        summary.innerHTML = "";
                    }
                    else if (cl2[m].byline == undefined){
                        console.log('cl2[m].byline is undefined');
                        byline.innerHTML = "";
                    }
                    else{
                        
                        header.innerHTML = cl2[m].headline;

                        byline.innerHTML = cl2[m].byline;

                        summary.innerHTML = cl2[m].summary;

                        for(var l = 0; l < divs.length; l++) {
                          docFrag.appendChild(divs[l]);
                          storyHolder.appendChild(docFrag );
                        }
  
                }

        }

      }
    }
}